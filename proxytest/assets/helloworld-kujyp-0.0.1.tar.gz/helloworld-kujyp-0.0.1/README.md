# pip-installable-package-example

### usage example
```bash
python app.py world
python app.py name kujyp
```

### after installation usage
- installation
```bash
python setup.py sdist
pip install dist/*.tar.gz
```
- usage
```bash
helloworld world
helloworld name kujyp
```
